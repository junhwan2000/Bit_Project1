package dto;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class QnaDTO {
	private String num;
	private String title;
	private String user_id;
	private String content;
	private Timestamp reg_date;
	private int ref;			// 그룹화 아이디
	private int re_step;		// 글순서
	private int re_level;
	
}
